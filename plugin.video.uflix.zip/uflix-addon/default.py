import xbmcaddon
import xbmcgui
import xbmcplugin

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

def list_movies():
    # Example function to list movies
    url = 'https://uflix.cc/api/movies'
    response = requests.get(url)
    movies = response.json()

    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=movie['url'], listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

if __name__ == '__main__':
    list_movies()