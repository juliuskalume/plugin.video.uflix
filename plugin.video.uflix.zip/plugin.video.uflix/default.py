import sys
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
args = sys.argv[2][1:]

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urlencode(query)

def list_movies():
    url = 'https://uflix.cc/api/movies'
    response = requests.get(url)
    movies = response.json()['movies']

    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setInfo('video', {'title': movie['title'], 'genre': movie['genre']})
        list_item.setArt({'thumb': movie['thumbnail'], 'poster': movie['poster']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=movie['url'], listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def list_series():
    url = 'https://uflix.to/api/series'
    response = requests.get(url)
    series = response.json()['series']

    for serie in series:
        list_item = xbmcgui.ListItem(label=serie['title'])
        list_item.setInfo('video', {'title': serie['title'], 'genre': serie['genre']})
        list_item.setArt({'thumb': serie['thumbnail'], 'poster': serie['poster']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=serie['url'], listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

if __name__ == '__main__':
    if args == 'movies':
        list_movies()
    elif args == 'series':
        list_series()
    else:
        xbmcplugin.endOfDirectory(addon_handle)