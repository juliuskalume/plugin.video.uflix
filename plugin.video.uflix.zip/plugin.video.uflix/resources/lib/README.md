# Uflix Kodi Addon

This is a Kodi addon to play movies and series from Uflix.

## Installation

1. Download the addon as a ZIP file.
2. Open Kodi and navigate to `Add-ons`.
3. Click on the open box icon at the top.
4. Select `Install from zip file`.
5. Locate and select the downloaded ZIP file.
6. Wait for the addon to be installed.

## Usage

1. Open the Uflix addon from the `Add-ons` menu.
2. Browse and play movies and series from Uflix.

## License

This project is licensed under the GPL v2.0 License.